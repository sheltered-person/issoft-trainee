﻿using System;

namespace Task1
{
    public class MatrixTracker<T>
    {
        //Store info about last action to undo it, if necessary.
        public ElementChangedEventArgs<T> LastAction { get; private set; }

        public DiagonalMatrix<T> TrackedMatrix { get; }

        public MatrixTracker(DiagonalMatrix<T> matrix)
        {
            if (matrix is null)
            {
                throw new ArgumentNullException("Error:" +
                    " tracked matrix can't be null.");
            }

            TrackedMatrix = matrix;
            TrackedMatrix.ElementChanged += ElementChangedHandler;
        }

        //Event handler method.
        private void ElementChangedHandler(object sender, 
            ElementChangedEventArgs<T> e)
        {
            LastAction = e;
        }

        //Undo last change in matrix, if there were some changes.
        public void Undo()
        {
            if (LastAction is null)
            {
                throw new NullReferenceException("Error: there is no actions" +
                    "with the matrix to undo.");
            }

            int i = LastAction.Index;
            TrackedMatrix[i, i] = LastAction.OldValue;
        }
    }
}
