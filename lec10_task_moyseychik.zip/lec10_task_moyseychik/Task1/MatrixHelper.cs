﻿using System;

namespace Task1
{
    public static class MatrixHelper
    {
        //Class with extension methods for DiagonalMatrix class.

        public static DiagonalMatrix<T> Add<T>(this DiagonalMatrix<T> matrix1, 
            DiagonalMatrix<T> matrix2, Func<T, T, T> additionMethod)
        {
            if (matrix1 is null || matrix2 is null || additionMethod is null)
            {
                throw new ArgumentNullException("Error: one of the required " +
                    "arguments was null.");
            }

            if (matrix1.Size < matrix2.Size)
            {
                DiagonalMatrix<T> temp = matrix1;
                matrix1 = matrix2;
                matrix2 = temp;
            }

            T[] elements = new T[matrix1.Size];

            for (int i = 0; i < matrix2.Size; i++)
            {
                elements[i] = additionMethod(matrix1[i, i], matrix2[i, i]);
            }

            for (int i = matrix2.Size; i < matrix1.Size; i++)
            {
                elements[i] = matrix1[i, i];
            }

            return new DiagonalMatrix<T>(matrix1.Size, elements);
        }
    }
}
